<?php
defined('_JEXEC') or die("Access Denied");

echo JTEXT::_('COM_MYCOMP_WELCOME');
