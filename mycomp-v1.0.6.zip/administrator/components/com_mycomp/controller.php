<?php

defined('_JEXEC') or die('access denied')

jimport ('joomla.application.component.controller');

class MyCompController extends JController{

	function create(){
		echo "backend create function";
		echo JText::_('COM_MYCOMP_TASK_CREATE');
	}
	
	function delete(){
		echo JText::_('COM_MYCOMP_TASK_DELETE');
	}
	
	function display(){
		echo "no task defined!";
		echo JText::_('COM_MYCOMP_WELCOME');
	}
	
}