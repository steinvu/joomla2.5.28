<?php
defined('_JEXEC') or die("Access Denied");

echo "<h3>Welkom in mycomp backend!</h3>";
